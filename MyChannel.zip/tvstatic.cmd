ffmpeg -y -i tvstatic.mp4 -c:v libx264 -b:v 512k -preset slow -maxrate 512k -bufsize 1024k -tune film -pass 1 -an -f null NUL 
ffmpeg -i tvstatic.mp4 -c:v libx264 -b:v 512k -vf scale=640:-1 -preset slow -maxrate 512k -bufsize 1024k -tune film -pass 2 -an tvstatic2p.mp4 
